let totalSeats = 80;

function loadSeats(isAdmin){
 let seats = JSON.parse(localStorage.getItem("seats"));

 if(!seats){
  seats = Array(totalSeats).fill("available");
 }

 let container = document.getElementById("seats");
 container.innerHTML = "";

 let availableCount = 0;

 seats.forEach((status, index) => {
  let div = document.createElement("div");
  div.classList.add("seat", status);
  div.innerText = index + 1;

  if(status === "available") availableCount++;

  if(isAdmin){
   div.onclick = function(){
    seats[index] = (seats[index] === "available") ? "occupied" : "available";
    localStorage.setItem("seats", JSON.stringify(seats));
    loadSeats(true);
   }
  }

  container.appendChild(div);
 });

 document.getElementById("available").innerText = availableCount;
}

function resetSeats(){
 let seats = Array(totalSeats).fill("available");
 localStorage.setItem("seats", JSON.stringify(seats));
 loadSeats(true);
}

function logout(){
 window.location = "login.html";
}